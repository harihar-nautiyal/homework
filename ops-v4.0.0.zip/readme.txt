# One Player Sleep
# Created: 12/07/2023 [dd/mm/yyyy]
# Author: FoxyNoTail
# Version: 4.0.0
# Made for Minecraft Bedrock Edition 1.20.10
# For more info visit www.foxynotail.com 

-- AKA Single Player Sleep --

WHAT'S NEW IN v4.0.0
------
Updated for 1.20.10

BIG UPDATE!
GOOD NEWS: This pack no longer conflicts with other add-ons that use the player entity.
BAD NEWS: You MUST be standing on a bed before you sleep to activate this!


What's Included?
--------
# One Player Sleep
This pack lets all players activate one player sleeping which means that on worlds with more than one player online, only one player needs to sleep to pass the night.
To activate, stand on a bed and then sleep in a bed.
This works on single player worlds, realms and servers.

Adding this pack to your world.
--------
Download the pack from https://foxynotail.com

# Single Player Worlds and Realms
Use the in game settings to add the behaviour pack to your world. 
To get the pack into the game on windows 10, double click the .mcaddon file you downloaded. It should install into Minecraft on it's own.
For other platforms, if trying to open the .mcaddon file doesn't work, copy the .mcaddon file into the behaviour_packs folder of your Minecraft bedrock installation.

# BDS Servers
Follow the instructions in the launch video here: https://youtu.be/Wu79wSllCkc

# Making the pack work
--------
One player sleep will work for all players.

# That's it!

I hope you managed ok. Any issues, then please contact me via my discord. Details can be found on https://foxynotail.com

FAQ:
Q) It doesn't work
A) Make sure you're standing on a bed before you sleep.


HELP & SUPPORT
------
For help and questions about Foxy's packs, please join the discord via the link below


LINKS
------
Discord: discord.gg/BqGKecr
YouTube: youtube.com/foxynotail
Twitch: twitch.tv/foxynotail
Twitter: twitter.com/FoxyNoTail
Website: www.foxynotail.com
